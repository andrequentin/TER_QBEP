Rendu prévisionnel du groupe TER_QBEP

Sujet de TER:
Programmation d'un drone pour la photogrammétrie

Membres du groupe :
ANDRÉ Quentin
DARNALA Baptiste
DUVERGER Eliott
VAN ISEGHEM Pierre

Contenu :
TER_QEP.pod contient le diagramme (gantt) prévisionel du TER.
